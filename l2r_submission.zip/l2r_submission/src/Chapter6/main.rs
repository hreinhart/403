use std::io::{self, BufRead, Write};
use std::env;
use std::fs;
use std::cell::RefCell;

mod scanner;
mod token;
mod expr;
mod ast_printer;
mod parser;

use crate::parser::Parser;
use crate::scanner::Scanner;
use crate::token::{Token, TokenType};
use crate::ast_printer::AstPrinter;
use crate::expr::{Expr, Binary, Grouping, Literal, Unary};

thread_local! {
    static HAD_ERROR: RefCell<bool> = RefCell::new(false);
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() > 2 {
        println!("Usage: rlox [script]");
        std::process::exit(64);
    } else if args.len() == 2 {
        run_file(&args[1]);
    } else {
        run_prompt();
    }
}

fn run_file(path: &str) {
    let full_path = format!("{}", path);
    println!("Running file: {}", full_path);
    let bytes = fs::read(full_path).expect("Failed to read file");
    let content = String::from_utf8(bytes).expect("Error converting bytes to string");

    if HAD_ERROR.with(|had_error| *had_error.borrow()) {
        std::process::exit(65);
    }

    run(content);
}

fn run_prompt() {
    let stdin = io::stdin();
    let mut reader = stdin.lock();
    loop {
        print!("> ");
        io::stdout().flush().unwrap();
        let mut line = String::new();
        let bytes_read = reader.read_line(&mut line).expect("Failed to read line");
        if bytes_read == 0 {
            break;
        }
        run(line.trim().to_string());

        HAD_ERROR.with(|had_error| *had_error.borrow_mut() = false);
    }
}

fn run(source: String) {
    let mut scanner = Scanner::new(source);
    let tokens = scanner.scan_tokens();
    let mut parser = Parser::new(tokens.to_vec());

    
    let printer = AstPrinter;
    
    while !parser.is_at_end() {
        match parser.parse(){
        Some(expression) => println!("{}", printer.print(&expression)),
        None => {
            eprintln!("Error: Failed to parse expression");
            break;
            }
        }
    }
}

fn error(line: usize, message: &str) {
    report(line, "", message);
}

fn report(line: usize, location: &str, message: &str) {
    eprintln!("[line {}] Error {}: {}", line, location, message);
    HAD_ERROR.with(|had_error| { *had_error.borrow_mut() = true });
}