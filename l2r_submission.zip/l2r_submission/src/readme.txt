This submission is for both me, Hunter Reinhart, and my partner, Drew Wolfe.

To build the project you enter the command cargo build l2r, but it should already be build and ready to run.

To run the program you have two options. Option one is to cd into src and type cargo run. This option will allow for user input to test in the terminal.
Option two is to cd into src and type cargo run test.lox. This option will run my current test file which includes all current functionality of the project.

My sample run output is included in the file testresults.txt. It is a completetion of the second option of running the program.