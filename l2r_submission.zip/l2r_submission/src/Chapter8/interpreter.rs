use crate::expr::{Expr, Binary, Grouping, Literal, Unary, ExprVisitor, Variable};
use crate::token::{Token, TokenType};
use crate::stmt::{Stmt, StmtVisitor};
use crate::runtime_error::RuntimeError;
use crate::environment::{Environment, Value};
use std::cell::RefCell;

pub struct Interpreter{
    environment: RefCell<Environment>,
}

impl Interpreter {
    pub fn new() -> Self {
        Interpreter{
            environment: RefCell::new(Environment::new()),
        }
    }

    pub fn interpret(&self, statements: Vec<Stmt>) -> Result<(), RuntimeError> {
        for statement in statements {
            match self.execute(&statement) {
                Ok(_) => {},
                Err(error) => {
                    return Err(error);
                }
            }
        }
        Ok(())
    }

    fn execute(&self, stmt: &Stmt) -> Result<(), RuntimeError> {
        //println!("Executing statement: {:?}", stmt); // Debug print
        stmt.accept(self)
    }

    fn executeblock(&self, statements: &Vec<Stmt>, environment: RefCell<Environment>) -> Result<(), RuntimeError> {
        //println!("Executing block: {:?}", statements); // Debug print
        let previous = self.environment.replace(environment.clone().into_inner());
        for statement in statements {
            //println!("Executing block statement: {:?}", statement); // Debug print
            match self.execute(statement) {
                Ok(_) => {},
                Err(error) => {
                    //println!("Error executing block statement: {:?}", error); // Debug print
                    self.environment.replace(previous);
                    return Err(error);
                }
            }
        }
        self.environment.replace(previous);
        Ok(())
    }

    fn evaluate(&self, expr: &Expr) -> Result<String, RuntimeError> {
        //println!("Evaluating expression: {:?}", expr); // Debug print
        expr.accept(self)
    }

    fn is_truthy(&self, value: &str) -> bool {
        match value {
            "false" => false,
            "nil" => false,
            _ => true,
        }
    }

    fn is_equal(&self, left: &str, right: &str) -> bool {
        if left == "nil" && right == "nil" {
            return true;
        }
        if left == "nil" {
            return false;
        }
        left == right
    }

    fn value_to_string(&self, value: &Value) -> String {
        match value {
            Value::String(s) => s.clone(),
            Value::Number(n) => n.to_string(),
            Value::Boolean(b) => b.to_string(),
            Value::Nil => "Nil".to_string(),
        }
    }

    fn check_number_operand(&self, operator: &Token, operand: &str) -> Result<(), RuntimeError> {
        if operand.parse::<f64>().is_err() {
            return Err(RuntimeError::new(operator.clone(), "Operand must be a number.".to_string()));
        }
        Ok(())
    }

    fn check_number_operands(&self, operator: &Token, left: &str, right: &str) -> Result<(), RuntimeError> {
        if left.parse::<f64>().is_err() || right.parse::<f64>().is_err() {
            return Err(RuntimeError::new(operator.clone(), "Operands must be numbers.".to_string()));
        }
        Ok(())
    }

    fn stringify(&self, value: Option<&str>) -> String {
        match value {
            None => "nil".to_string(),
            Some(v) => {
                if let Ok(num) = v.parse::<f64>() {
                    let mut text = num.to_string();
                    if text.ends_with(".0") {
                        text.truncate(text.len() - 2);
                    }
                    text
                } else {
                    v.to_string()
                }
            }
        }
    }
}

impl ExprVisitor<Result<String, RuntimeError>> for Interpreter {
    fn visit_binary_expr(&self, expr: &Binary) -> Result<String, RuntimeError> {
        let left = self.evaluate(&expr.left)?;
        let right = self.evaluate(&expr.right)?;

        match expr.operator.kind {
            TokenType::Plus => {
                if let (Ok(left_num), Ok(right_num)) = (left.parse::<f64>(), right.parse::<f64>()) {
                    Ok((left_num + right_num).to_string())
                } else if left.parse::<f64>().is_err() && right.parse::<f64>().is_err() {
                    Ok(format!("{}{}", left, right))
                } else {
                    return Err(RuntimeError::new(expr.operator.clone(), "Operands must be two numbers or two strings.".to_string()));
                }
            }
            TokenType::Minus => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num - right_num).to_string())
            }
            TokenType::Star => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num * right_num).to_string())
            }
            TokenType::Slash => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num / right_num).to_string())
            }
            TokenType::Greater => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num > right_num).to_string())
            }
            TokenType::GreaterEqual => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num >= right_num).to_string())
            }
            TokenType::Less => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num < right_num).to_string())
            }
            TokenType::LessEqual => {
                self.check_number_operands(&expr.operator, &left, &right)?;
                let left_num: f64 = left.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                let right_num: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((left_num <= right_num).to_string())
            }
            TokenType::EqualEqual => Ok(self.is_equal(&left, &right).to_string()),
            TokenType::BangEqual => Ok((!self.is_equal(&left, &right)).to_string()),
            _ => Err(RuntimeError::new(expr.operator.clone(), "Unknown binary operator.".to_string())),
        }
    }

    fn visit_grouping_expr(&self, expr: &Grouping) -> Result<String, RuntimeError> {
        self.evaluate(&expr.expression)
    }

    fn visit_literal_expr(&self, expr: &Literal) -> Result<String, RuntimeError> {
        match expr {
            Literal::Bool(value) => Ok(value.to_string()),
            Literal::Nil => Ok("nil".to_string()),
            Literal::Number(value) => Ok(value.to_string()),
            Literal::String(value) => Ok(value.clone()),
        }
    }

    fn visit_unary_expr(&self, expr: &Unary) -> Result<String, RuntimeError> {
        let right = self.evaluate(&expr.right)?;

        match expr.operator.kind {
            TokenType::Minus => {
                self.check_number_operand(&expr.operator, &right)?;
                let number: f64 = right.parse().map_err(|_| RuntimeError::new(expr.operator.clone(), "Expected a number.".to_string()))?;
                Ok((-number).to_string())
            }
            TokenType::Bang => Ok((!self.is_truthy(&right)).to_string()),
            _ => Err(RuntimeError::new(expr.operator.clone(), "Unknown unary operator.".to_string())),
        }
    }

    fn visit_variable_expr(&self, expr: &Variable) -> Result<String, RuntimeError> {
        //println!("Evaluating variable: {:?}", expr.name); // Debug print
        let value = self.environment.borrow().get(&expr.name);
        let value = value.map_err(|e| RuntimeError::new(expr.name.clone(), e))?;
        Ok(self.value_to_string(&value))
    }

    fn visit_assign_expr(&self, name: &Token, value: &Expr) -> Result<String, RuntimeError> {
        //println!("Visiting assign expression: {:?} = {:?}", name, value); // Debug print
        let value = self.evaluate(value)?;
        self.environment.borrow_mut().assign(name, Value::String(value.clone()))?;
        Ok(value)
    }

}

impl StmtVisitor<Result<(), RuntimeError>> for Interpreter {
    fn visit_expression_stmt(&self, stmt: &Stmt) -> Result<(), RuntimeError> {
        if let Stmt::Expression(expr) = stmt {
            self.evaluate(expr)?;
        }
        Ok(())
    }

    fn visit_print_stmt(&self, stmt: &Stmt) -> Result<(), RuntimeError> {
        if let Stmt::Print(expr) = stmt {
            let value = self.evaluate(expr)?;
            println!("{}", value);
        }
        Ok(())
    }
    
    fn visit_var_stmt(&self, stmt: &Stmt) -> Result<(), RuntimeError> {
        if let Stmt::Var(name, initializer) = stmt {
            //println!("Visiting var statement: {:?} = {:?}", name, initializer); // Debug print
            let value = match initializer {
                Some(init_expr) => self.evaluate(init_expr)?,
                None => String::from("Nil"),
            };
            self.environment.borrow_mut().define(name.lexeme.clone(), Value::String(value));
        }
        Ok(())
    }

    fn visit_block_stmt(&self, stmt: &Stmt) -> Result<(), RuntimeError> {
        if let Stmt::Block(statements) = stmt {
            let environment = RefCell::new(Environment::new_with_enclosing(self.environment.clone().into()));
            self.executeblock(statements, environment)?;
        }
        Ok(())
    }
}