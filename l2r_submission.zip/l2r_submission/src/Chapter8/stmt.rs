use crate::expr::Expr;
use crate::token::Token;

pub trait StmtVisitor<R> {
    fn visit_expression_stmt(&self, stmt: &Stmt) -> R;
    fn visit_print_stmt(&self, stmt: &Stmt) -> R;
    fn visit_var_stmt(&self, stmt: &Stmt) -> R;
    fn visit_block_stmt(&self, stmt: &Stmt) -> R;
}

#[derive(Debug, Clone)]
pub enum Stmt {
    Expression(Expr),
    Print(Expr),
    Var(Token, Option<Expr>),
    Block(Vec<Stmt>),
}

impl Stmt {
    pub fn accept<R>(&self, visitor: &dyn StmtVisitor<R>) -> R {
        match self {
            Stmt::Expression(_expr) => visitor.visit_expression_stmt(self),
            Stmt::Print(_expr) => visitor.visit_print_stmt(self),
            Stmt::Var(_token, _expr) => visitor.visit_var_stmt(self),
            Stmt::Block(_stmts) => visitor.visit_block_stmt(self),
        }
    }
}