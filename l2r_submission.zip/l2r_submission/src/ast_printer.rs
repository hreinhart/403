use crate::expr::{Expr, Literal, Binary,
Unary, Grouping, ExprVisitor, Variable, Logical};
use crate::token::Token;

pub struct AstPrinter;

impl AstPrinter {
    pub fn print(&self, expr: &Expr) -> String {
        expr.accept(self)
    }
}

impl ExprVisitor<String> for AstPrinter {
    fn visit_binary_expr(&self, expr: &Binary) -> String {
        format!("({} {} {})", expr.operator.lexeme, self.print(&expr.left), self.print(&expr.right))
    }

    fn visit_grouping_expr(&self, expr: &Grouping) -> String {
        format!("(group {})", self.print(&expr.expression))
    }

    fn visit_literal_expr(&self, expr: &Literal) -> String {
        match expr {
            Literal::Bool(value) => value.to_string(),
            Literal::Nil => "nil".to_string(),
            Literal::Number(value) => value.to_string(),
            Literal::String(value) => format!("\"{}\"", value), // Add quotes around string literals
        }
    }

    fn visit_unary_expr(&self, expr: &Unary) -> String {
        format!("({} {})", expr.operator.lexeme, self.print(&expr.right))
    }

    fn visit_variable_expr(&self, expr: &Variable) -> String {
        expr.name.lexeme.clone()
    }

    fn visit_assign_expr(&self, name: &Token, value: &Expr) -> String {
        format!("({} = {})", name.lexeme, self.print(value))
    }

    fn visit_logical_expr(&self, expr: &Logical) -> String {
        format!("({} {} {})", expr.operator.lexeme, self.print(&expr.left), self.print(&expr.right))
    }
}