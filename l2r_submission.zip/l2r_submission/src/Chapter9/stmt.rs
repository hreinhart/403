use crate::expr::Expr;
use crate::token::Token;

pub trait StmtVisitor<R> {
    fn visit_expression_stmt(&self, stmt: &Stmt) -> R;
    fn visit_print_stmt(&self, stmt: &Stmt) -> R;
    fn visit_var_stmt(&self, stmt: &Stmt) -> R;
    fn visit_block_stmt(&self, stmt: &Stmt) -> R;
    fn visit_if_stmt(&self, stmt: &Stmt) -> R;
    fn visit_while_stmt(&self, stmt: &Stmt) -> R;
    fn visit_for_stmt(&self, stmt: &Stmt) -> R;
}

#[derive(Debug, Clone)]
pub enum Stmt {
    Expression(Expr),
    Print(Expr),
    Var(Token, Option<Expr>),
    Block(Vec<Stmt>),
    If(Expr, Box<Stmt>, Option<Box<Stmt>>),
    While(Expr, Box<Stmt>),
    For(Token, Expr, Box<Stmt>),
}

impl Stmt {
    pub fn accept<R>(&self, visitor: &dyn StmtVisitor<R>) -> R {
        match self {
            Stmt::Expression(_expr) => visitor.visit_expression_stmt(self),
            Stmt::Print(_expr) => visitor.visit_print_stmt(self),
            Stmt::Var(_token, _expr) => visitor.visit_var_stmt(self),
            Stmt::Block(_stmts) => visitor.visit_block_stmt(self),
            Stmt::If(_expr, _then_branch, _else_branch) => visitor.visit_if_stmt(self),
            Stmt::While(_expr, _stmt) => visitor.visit_while_stmt(self),
            Stmt::For(_token, _expr, _stmt) => visitor.visit_for_stmt(self),
        }
    }
}