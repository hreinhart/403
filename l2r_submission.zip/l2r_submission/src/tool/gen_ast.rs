use std::env;
use std::fs::File;
use std::io::{self, Write};
use std::path::Path;

fn main() -> io::Result<()> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 2 {
        eprintln!("Usage: generate_ast <output directory>");
        std::process::exit(64);
    }
    let output_dir = &args[1];
    define_ast(output_dir, "Expr", vec![
        "Binary   : Box<Expr> left, Token operator, Box<Expr> right",
        "Grouping : Box<Expr> expression",
        "Literal  : Option<Object> value",
        "Unary    : Token operator, Box<Expr> right",
    ])?;
    Ok(())
}

fn define_ast(output_dir: &str, base_name: &str, types: Vec<&str>) -> io::Result<()> {
    let path = Path::new(output_dir).join(format!("{}.rs", base_name.to_lowercase()));
    let mut file = File::create(&path)?;

    writeln!(file, "use crate::token::Token;")?;
    writeln!(file, "use crate::object::Object;")?;
    writeln!(file)?;

    // Call define_visitor
    define_visitor(&mut file, base_name, &types)?;

    writeln!(file, "pub enum {} {{", base_name)?;
    for t in &types {
        let type_name = t.split(':').next().unwrap().trim();
        writeln!(file, "    {}({}),", type_name, type_name)?;
    }
    writeln!(file, "}}")?;
    writeln!(file)?;

    writeln!(file, "impl {} {{", base_name)?;
    writeln!(file, "    pub fn accept<R>(&self, visitor: &dyn Visitor<R>) -> R {{")?;
    writeln!(file, "        match self {{")?;
    for t in &types {
        let type_name = t.split(':').next().unwrap().trim();
        writeln!(file, "            {}::{}(expr) => visitor.visit_{}_{}(expr),", base_name, type_name, type_name.to_lowercase(), base_name.to_lowercase())?;
    }
    writeln!(file, "        }}")?;
    writeln!(file, "    }}")?;
    writeln!(file, "}}")?;
    writeln!(file)?;

    // Iterate over types and call define_type
    for t in &types {
        let parts: Vec<&str> = t.split(':').collect();
        let class_name = parts[0].trim();
        let fields = parts[1].trim();
        define_type(&mut file, base_name, class_name, fields)?;
    }

    Ok(())
}

fn define_visitor(file: &mut File, base_name: &str, types: &[&str]) -> io::Result<()> {
    writeln!(file, "pub trait Visitor<R> {{")?;
    for t in types {
        let type_name = t.split(':').next().unwrap().trim();
        writeln!(file, "    fn visit_{}_{}(&self, expr: &{}) -> R;", type_name.to_lowercase(), base_name.to_lowercase(), type_name)?;
    }
    writeln!(file, "}}")?;
    Ok(())
}

fn define_type(file: &mut File, base_name: &str, class_name: &str, field_list: &str) -> io::Result<()> {
    writeln!(file, "pub struct {} {{", class_name)?;
    for field in field_list.split(", ") {
        writeln!(file, "    pub {},", field)?;
    }
    writeln!(file, "}}")?;
    writeln!(file)?;
    writeln!(file, "impl {} {{", class_name)?;
    writeln!(file, "    pub fn new({}) -> Self {{", field_list)?;
    writeln!(file, "        {} {{", class_name)?;
    for field in field_list.split(", ") {
        let name = field.split(' ').nth(1).unwrap();
        writeln!(file, "            {},", name)?;
    }
    writeln!(file, "        }}")?;
    writeln!(file, "    }}")?;
    writeln!(file, "}}")?;
    writeln!(file)?;
    writeln!(file, "impl {} for {} {{", base_name, class_name)?;
    writeln!(file, "    fn accept<R>(&self, visitor: &dyn Visitor<R>) -> R {{")?;
    writeln!(file, "        visitor.visit_{}_{}(self)", class_name.to_lowercase(), base_name.to_lowercase())?;
    writeln!(file, "    }}")?;
    writeln!(file, "}}")?;
    Ok(())
}